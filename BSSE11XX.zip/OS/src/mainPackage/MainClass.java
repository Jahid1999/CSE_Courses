package mainPackage;

public class MainClass {

    public static void main(String[] args) {
        Producer_Consumer proCon = new Producer_Consumer();
        proCon.start();
    }
}
